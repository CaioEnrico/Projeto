#Esse projeto tem como objetivo por em prática os conceitos aprendidos em Banco de Dados e Programação Orientada a Obejetos.

#Foram Utilizado Java e MySQL para a criação do mesmo.

O projeto HotelList funciona como uma lista de hotéis disponíveis e um meio de cadastro para uma pessoa que seja hóspede ou empregado se cadastre no sistema e esteja com tudo em ordem.
Com as limitações obtidas, o projeto mostra de uma maneira "bruta" como é o funcionamento dos sites de bookings de aviao.
