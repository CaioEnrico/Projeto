package checkInOut;

public interface FazCheckIn {

    public void fazCheckIn();
}
