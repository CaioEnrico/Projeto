package checkInOut;

public interface FazCheckOut {
    public void fazCheckOut();
}
