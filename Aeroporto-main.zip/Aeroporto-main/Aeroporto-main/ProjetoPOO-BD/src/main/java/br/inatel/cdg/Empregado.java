package br.inatel.cdg;

public class Empregado extends Pessoa{


    public Empregado(String nome, String cpf,String ocupacao, int idade) {
        super(nome, cpf,ocupacao, idade);
    }
}
