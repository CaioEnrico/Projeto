package br.inatel.cdg;

public class Aviao {

    public int idAviao;
    private String nome;
    private int qtdAssentos;

    Classe q = new Classe();



    //Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtdAssentos() {
        return qtdAssentos;
    }

    public void setQtdAssentos(int qtdAssentos) {
        this.qtdAssentos = qtdAssentos;
    }
}
