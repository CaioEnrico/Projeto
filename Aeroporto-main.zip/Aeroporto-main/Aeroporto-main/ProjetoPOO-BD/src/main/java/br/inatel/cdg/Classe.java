package br.inatel.cdg;

public class Classe {

    private String tipoClasse;


    //Getters e Setters
    public String getTipoClasse() {
        return tipoClasse;
    }

    public void setTipoClasse(String tipoClasse) {
        this.tipoClasse = tipoClasse;
    }
}
